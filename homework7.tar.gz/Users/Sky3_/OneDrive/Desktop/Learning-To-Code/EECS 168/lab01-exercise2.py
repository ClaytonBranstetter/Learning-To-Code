'''
Author: Clayton Branstetter
KUID: 3089206
Date: 09/21/2021
Lab: lab#01
Last modified: 09/21/2021
Purpose: Introducing myself in code
'''


def user(name, major):
  print("My name is {}\nI major in {}\nMy hobbies are\n\tCoding\n\tAnime\n\tCooking\n\tLeague of Legends".format(name, major))
user("Clayton Branstetter", "Computer Science")

