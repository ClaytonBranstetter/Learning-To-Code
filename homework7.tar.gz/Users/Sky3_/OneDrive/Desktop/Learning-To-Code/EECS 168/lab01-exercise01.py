'''
Author: Clayton Branstetter
KUID: 3089206
Date: 09/21/2021
Lab: Lab#01
Last modified: 09/21/2021
Purpose: This is my first lab exercise!
'''

print("This is my first lab exercise")