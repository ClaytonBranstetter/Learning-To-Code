'''
Author: Clayton Branstetter
KUID: 3089206
Date: 10/02/2021
Lab: lab#03
Last modified: 10/02/2021
Purpose: Going to the Grocery Store
'''
